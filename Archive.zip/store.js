import {atom} from 'jotai';


export const favoruitesAtom = atom([]);
export const searchHistoryAtom = atom([])

